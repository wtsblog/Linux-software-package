function NodeStats(id, stats) {
  this.id = id;
  this.name = stats.name;
  this.stats = stats;
}
