int nds_get_password(LDAP *ld, char *object_dn, size_t * pwd_len, char *pwd);
