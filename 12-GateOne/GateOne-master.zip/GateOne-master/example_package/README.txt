To install this example package:

    $ sudo python setup.py install

To build the documentation:

    $ cd docs; make html
