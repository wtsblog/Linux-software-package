:mod:`pam.py` - A PAM Authentication Module
===============================================

.. moduleauthor:: Alan Schmitz (Thanks!)

.. automodule:: gateone.auth.pam
    :members:
    :private-members:
