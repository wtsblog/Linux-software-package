:mod:`authentication.py` - Authentication Classes
=================================================

.. moduleauthor:: Dan McDougall <daniel.mcdougall@liftoffsoftware.com>

.. automodule:: gateone.auth.authentication
    :members:
    :private-members:
