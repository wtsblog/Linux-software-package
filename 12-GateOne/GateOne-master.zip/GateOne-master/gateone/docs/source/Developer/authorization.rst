:mod:`authorization.py` - Authentication Classes
================================================

.. moduleauthor:: Dan McDougall <daniel.mcdougall@liftoffsoftware.com>

.. automodule:: gateone.auth.authorization
    :members:
    :private-members:
