:mod:`termio.py` - Terminal Input/Output Module
===============================================

.. moduleauthor:: Dan McDougall <daniel.mcdougall@liftoffsoftware.com>

.. automodule:: termio
    :members:
    :private-members:
