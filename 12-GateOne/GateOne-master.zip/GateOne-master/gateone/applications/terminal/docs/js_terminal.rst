.. _terminal-javascript:

terminal.js
===========
Gate One's bundled Terminal application JavaScript (`source <https://github.com/liftoff/GateOne/blob/master/gateone/applications/terminal/static/terminal.js>`_).

.. autojs:: ../applications/terminal/static/terminal.js
    :member-order: bysource
    :members: GateOne.Terminal
