.. _terminal-input-javascript:

terminal_input.js
=================
Gate One's bundled Terminal application JavaScript (Input module) (`source <https://github.com/liftoff/GateOne/blob/master/gateone/applications/terminal/static/terminal_input.js>`_).

.. autojs:: ../applications/terminal/static/terminal_input.js
    :member-order: bysource
    :members: GateOne.Terminal.Input
