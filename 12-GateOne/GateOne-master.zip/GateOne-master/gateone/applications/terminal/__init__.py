from .app_terminal import init, apps, web_handlers, commands
