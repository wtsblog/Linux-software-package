Font Sources
============

Most
----
With the exception of a few (enumerated below), all of these these fonts come
from Google's Web Font directory:

http://www.google.com/fonts/

Others
------
The Liberation Mono font is copyright Red Hat and is distributed under the Red
Hat Liberation License which is included in this same directory.

The Source Code Pro font is Copyright 2010, 2012 Adobe Systems Incorporated and
distributed under the SIL Open Font License which is included in this same
directory.
