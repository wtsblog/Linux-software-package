#!/usr/bin/perl -w
# Modify by xok.la,http://xok.la/2010/04/cacti_netstat_tcp.html
# --------------------------------------------------
# ARGV[0] = <hostname> 		required
# ARGV[1] = <snmp version> 	required
# ARGV[2] = <snmp community> 	required
# ARGV[3] = <snmp port> 	required
# ARGV[4] = <snmp timeout> 	required
# --------------------------------------------------
$in_hostname 	= $ARGV[0] if defined $ARGV[0];
$in_version 	= $ARGV[1] if defined $ARGV[1];
$in_community 	= $ARGV[2] if defined $ARGV[2];
$in_port 	= $ARGV[3] if defined $ARGV[3];
$in_timeout 	= $ARGV[4] if defined $ARGV[4];

if ($in_version eq "2")
{
        $in_version = "2c";
}

#my $_cmd	= "snmpnetstat -v $in_version  -c $in_community -t $in_timeout -n -P tcp $in_hostname:$in_port";
my $_cmd	= "snmpnetstat -v $in_version  -c $in_community -t $in_timeout -Cn -Cp tcp $in_hostname:$in_port";

# usage notes
if (
	( ! defined $in_hostname ) ||
	( ! defined $in_version ) ||
	( ! defined $in_community ) ||
	( ! defined $in_port ) ||
	( ! defined $in_timeout )
	) {
	print 	"usage:\n\n
		$0 <host> <snmp version> < snmp community> <snmp port> <snmp timeout>\n\n";
	exit;
}



my @_output = `$_cmd`;

my $_estab	= 0;
my $_listen	= 0;
my $_timewait	= 0;
my $_timeclose	= 0;
my $_finwait1	= 0;
my $_finwait2	= 0;
my $_synsent	= 0;
my $_synrecv	= 0;
my $_closewait 	= 0;

#print "$_output\n";

foreach ( @_output ) {
	#print $_;
	$_estab++ 	if /ESTABLISHED/;
	$_listen++ 	if /LISTEN/;
	$_timewait++ 	if /TIMEWAIT/;
	$_timeclose++ 	if /TIMECLOSE/;
	$_finwait1++ 	if /FINWAIT1/;
	$_finwait2++ 	if /FINWAIT2/;
	$_synsent++ 	if /SYNSENT/;
	$_synrecv++ 	if /SYNRECV/;
	$_closewait++ 	if /CLOSEWAIT/;
}

#
print "established:$_estab listen:$_listen timewait:$_timewait timeclose:$_timeclose finwait1:$_finwait1 finwait2:$_finwait2 synsent:$_synsent synrecv:$_synrecv closewait:$_closewait";

